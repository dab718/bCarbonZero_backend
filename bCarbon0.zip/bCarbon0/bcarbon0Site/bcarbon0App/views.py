from django.shortcuts import render
from .fourms import SignUpForm
from django.contrib import messages
from django.shortcuts import render
# Create your views here.

def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save();
            messages.success(request, 'Account Created')
            return render(request, 'bCarbon0.html')
        else:
            form = SignUpForm()
        render(request, 'bCarbon0.html')