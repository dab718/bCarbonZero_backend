from django.contrib import admin
from .models import SiteUsers
# Register your models here.

admin.site.register(SiteUsers)